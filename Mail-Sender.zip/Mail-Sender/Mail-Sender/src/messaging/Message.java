package messaging;

import java.time.LocalDateTime;

public class Message {

    // --------------------- Attributes -----------------
    private Long id;
    private Chat chat;

    private String sender; // either "doctor" or "patient"
    private String text;

    private LocalDateTime sentAt;

    // --------------------- Constructors ---------------------
    public Message(Chat chat, String sender, String text) {
        this.chat = chat;
        this.sender = sender;
        this.text = text;
    }

    // Default constructor for JPA
    protected Message() {}

    // --------------------- Lifecycle Callback ---------------------
    protected void onCreate() {
        this.sentAt = LocalDateTime.now();
    }

    // --------------------- Getters & Setters ---------------------
    public Long getId() {
        return id;
    }

    public Chat getChat() {
        return chat;
    }

    public void setChat(Chat chat) {
        this.chat = chat;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    // Optional: if you want to allow manual setting
    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }
}
