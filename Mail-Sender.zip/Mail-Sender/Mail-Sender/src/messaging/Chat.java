package messaging;

import java.util.ArrayList;
import java.util.List;

public class Chat {

    // --------------------- Attributes --------------
    private Long id;

    private Long doctorId;
    private Long patientId;

    private List<Message> messages = new ArrayList<>();

    // --------------------- Constructor ---------------------
    public Chat(Long doctorId, Long patientId) {
        if (doctorId == null || patientId == null) {
            throw new IllegalArgumentException("Doctor ID and Patient ID cannot be null.");
        }
        this.doctorId = doctorId;
        this.patientId = patientId;
    }

    // Default constructor for JPA
    public Chat() {}

    // --------------------- Getters & Setters ---------------------
    public Long getId() {
        return id;
    }

    public Long getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(Long doctorId) {
        this.doctorId = doctorId;
    }

    public Long getPatientId() {
        return patientId;
    }

    public void setPatientId(Long patientId) {
        this.patientId = patientId;
    }

    public List<Message> getMessages() {
        return messages;
    }

    public void setMessages(List<Message> messages) {
        this.messages = messages;
    }

    public void addMessage(Message message) {
        messages.add(message);
        message.setChat(this);
    }

    public void removeMessage(Message message) {
        messages.remove(message);
        message.setChat(null);
    }
}
